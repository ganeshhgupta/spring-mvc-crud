### TOOLS & TECHNOLOGIES
  1. Eclipse/STS
  2. Gradle
  3. Spring Framework
  4. jQuery

### CONCEPTS/TOPICS COVERED
  1.  Expand Collapse with jQuery

### HOW TO RUN?
Run As -> Run on Server -> Tomcat Server </br>
http://localhost:8080/springmvc-gralde/
