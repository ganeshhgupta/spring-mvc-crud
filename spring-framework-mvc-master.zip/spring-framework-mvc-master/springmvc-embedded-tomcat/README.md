## TOOLS & TECHNOLOGIES
1. Java 1.8
2. Embedded Tomcat

## CONCEPTS COVERED
1. JdbcTemplate
