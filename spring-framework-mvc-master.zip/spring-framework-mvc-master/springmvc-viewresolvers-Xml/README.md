## TOOLS & TECHNOLOGIES
1. Java 1.8
2. Spring 5

## TOPICS COVERED
1. XmlViewResolver
2. Bean configuration using Annotation


## HOW TO RUN?
1. http://localhost:8080/springmvc-ViewResolver-XmlViewResolver/product
2. http://localhost:8080/springmvc-ViewResolver-XmlViewResolver/user