## TOOLS & TECHNOLOGIES
1. Java 1.8
2. Spring 5

## TOPICS COVERED
1. ContentNegotiatingViewResolver


## HOW TO RUN
#### JSP Response
http://localhost:8080/spring5mvc-view-resolver/persons/ranjith

#### PDF Response
http://localhost:8080/spring5mvc-view-resolver/persons/ranjith.pdf

#### JSON Response
http://localhost:8080/spring5mvc-view-resolver/persons/ranjith.json

#### Excel Response
http://localhost:8080/spring5mvc-view-resolver/persons/ranjith.xslx

