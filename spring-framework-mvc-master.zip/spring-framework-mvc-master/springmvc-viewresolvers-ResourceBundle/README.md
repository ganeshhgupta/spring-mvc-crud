## TOOLS & TECHNOLOGIES
1. Java 1.8
2. Spring 5

## TOPICS COVERED
1. ResourceBundleViewResolver
2. Annotation based bean configuration

## HOW TO RUN
1. http://localhost:8080/springmvc-ViewResolver-ResourceBundleViewResolver/user
2. http://localhost:8080/springmvc-ViewResolver-ResourceBundleViewResolver/product

