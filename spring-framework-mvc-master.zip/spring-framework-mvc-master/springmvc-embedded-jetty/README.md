## TOOLS & TECHNOLOGIES
  1. Java 1.8
  2. Spring Framework

## TOPICS COVERED
  1. 
  
## STEPS to run Application
1. Install Jetty Eclipse Plugin / Run Jetty Plugin
2. Right click the Application
3. Run As -> Run Configurations -> Jetty Webapp
4. WebApp->Context Path
  4.1 Replace / with /spring-mvc-embedded-jetty in 
  4.2 Change the port if required
5. Common
  5.1 Select Run Checkbox
